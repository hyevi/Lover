LOVER — установщик прошивки для PSP
by olxor

1. Подключите PSP к компьютеру по USB.
2. На PSP: Настройки → USB-подключение.
3. Дождитесь появления диска PSP.
4. Запустите LOVER-Installer.exe и нажмите «Установить».

Программа скачает и установит:
  • LOVER (наш лаунчер и тема)
  • FasterARK (прошивка ARK-5)
  • PKGi
  • CMFileManager
  • SNES9x
  • PSP-FTPD

После установки отключите USB и запустите FasterARK на PSP.