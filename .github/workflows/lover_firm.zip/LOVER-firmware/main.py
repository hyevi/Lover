import json
import sys
import shutil
import zipfile
import tempfile
import urllib.request
import tkinter as tk
from tkinter import messagebox
from pathlib import Path


def resource_path(rel: str) -> Path:
    """Ищет файл внутри .exe (PyInstaller) или рядом с main.py."""
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / rel
    return Path(__file__).parent / rel


def find_psp_drive():
    for letter in "DEFGHIJKLMNOPQRSTUVWXYZ":
        d = Path(f"{letter}:\\")
        try:
            if d.exists() and (d / "PSP" / "GAME").exists():
                return d
        except OSError:
            continue
    return None


def load_config():
    with open(resource_path("config.json"), "r", encoding="utf-8") as f:
        return json.load(f)


def download_install(url: str, psp_root: Path, name: str):
    """Скачивает zip и раскладывает по PSP/GAME или PSP/."""
    with urllib.request.urlopen(url, timeout=120) as r:
        data = r.read()
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        z = tmp / "app.zip"
        z.write_bytes(data)
        with zipfile.ZipFile(z) as zf:
            zf.extractall(tmp)

        # Если архив уже имеет структуру PSP/ — кладём в корень карты
        if (tmp / "PSP").exists():
            shutil.copytree(tmp / "PSP", psp_root / "PSP", dirs_exist_ok=True)
            return

        # Иначе — кладём всю распаковку в PSP/GAME/<name>/
        target = psp_root / "PSP" / "GAME" / name
        target.mkdir(parents=True, exist_ok=True)
        for item in tmp.iterdir():
            if item.name == "app.zip":
                continue
            if item.is_dir():
                shutil.copytree(item, target / item.name, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target / item.name)


def copy_launcher(psp_root: Path, install_to: str):
    """Копирует наш лаунчер (папка launcher/) в указанное место на PSP."""
    src = resource_path("launcher")
    if not src.exists():
        return
    dst = psp_root / install_to
    dst.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dst, dirs_exist_ok=True)


def install():
    psp = find_psp_drive()
    if not psp:
        messagebox.showerror(
            "Ошибка",
            "Диск PSP не найден.\n\n"
            "1. Подключите PSP по USB.\n"
            "2. На PSP: Настройки → USB-подключение.\n"
            "3. Дождитесь появления диска PSP и нажмите «Установить».",
        )
        return

    try:
        cfg = load_config()
    except Exception as e:
        messagebox.showerror("Ошибка", f"Не удалось прочитать config.json:\n{e}")
        return

    # 1. Наш лаунчер
    try:
        copy_launcher(psp, cfg["launcher"]["install_to"])
    except Exception as e:
        messagebox.showwarning("Лаунчер", f"Не удалось скопировать лаунчер:\n{e}")

    # 2. Приложения из config.json
    errors = []
    for app in cfg["apps"]:
        name = app["name"]
        try:
            download_install(app["url"], psp, name.replace(" ", "_"))
        except Exception as e:
            errors.append(f"{name}: {e}")

    if errors:
        messagebox.showwarning(
            "Готово с ошибками",
            "Не удалось установить:\n\n" + "\n".join(errors) +
            "\n\nПроверь config.json — возможно, изменилось имя ассета в релизе.",
        )
    else:
        messagebox.showinfo(
            "Готово!",
            "Все приложения установлены на карту памяти.\n\n"
            "Далее на PSP:\n"
            "1. Отключите USB.\n"
            "2. Игра → Memory Stick → запустите FasterARK.\n"
            "3. После прошивки зайдите в LOVER и в остальные приложения из меню «Игра».",
        )


root = tk.Tk()
root.title("LOVER — Установщик")
root.geometry("560x480")
root.resizable(False, False)

tk.Label(root, text="LOVER", font=("Arial", 26, "bold"), fg="#ff2e4d").pack(pady=(20, 0))
tk.Label(root, text="by olxor", font=("Arial", 10), fg="#6b7690").pack()

info = (
    "1. Подключите PSP к компьютеру по USB.\n"
    "2. На PSP: Настройки → USB-подключение.\n"
    "3. Дождитесь появления диска PSP.\n"
    "4. Нажмите «Установить».\n\n"
    "Будет установлено:\n"
    "• LOVER (наш лаунчер)\n"
    "• FasterARK (прошивка ARK-5)\n"
    "• PKGi, CMFileManager, SNES9x, PSP-FTPD"
)
tk.Label(root, text=info, justify="left", font=("Arial", 10), fg="#e8eef8").pack(pady=20, padx=30, anchor="w")

tk.Button(
    root, text="Установить", command=install,
    bg="#ff2e4d", fg="white", font=("Arial", 12, "bold"),
    padx=30, pady=10,
).pack(pady=10)

root.mainloop()